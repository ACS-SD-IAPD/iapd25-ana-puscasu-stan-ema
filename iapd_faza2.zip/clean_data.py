import requests
import time
import os
import random
from statistics import median
from collections import Counter
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import re

INPUT_CSV = "openlibrary_3000_v2.csv"
OUTPUT_CSV = "openlibrary_3000_clean_v2.csv"


BAD_TOKENS = {
        "f",
        "xx",
        "xxk",
        "idk",
        "unknown",
        "[publisher not identified]",
        "publisher not identified",
        "[s.n.]",
        "n.p.",
    }

def split_list_str(text):
    """
    Split a string into tokens using both ',' and ';' as separators.

    Example:
        "Fiction; Fantasy, Science fiction"
        -> ["Fiction", "Fantasy", "Science fiction"]
    """
    if not isinstance(text, str):
        return []

    tokens = re.split(r"[;,]", text)
    return [t.strip() for t in tokens if t.strip()]


def clean_publisher(publisher_value):
    """
    Clean the 'publisher' column into 'publisher_clean'.

    Goals:
    - Remove obviously useless tokens such as: 'xx', 'idk', 'unknown', etc.
    - Remove outer square brackets if present: "[London]" -> "London".
    - Keep meaningful publisher strings as they are (we do NOT normalize
      or translate them, to stay close to original data).
    """
    if not isinstance(publisher_value, str):
        return np.nan

    s = publisher_value.strip()

    
    if s.startswith("[") and s.endswith("]"):
        s = s[1:-1].strip()

    
    if s.lower() in BAD_TOKENS:
        return np.nan

    s = publisher_value.strip().lower()

    
    s = re.sub(r"\s+", " ", s)

    return s


def clean_publish_place(place_value):
    """
    Clean the 'publish_place' column into 'publish_place_clean'.

    Goals:
    - Remove outer square brackets: "[London]" -> "London".
    - Treat 'xx' as unknown / missing (set to NaN).
    - Keep other values as they are (we do not try to unify 'NY, USA'
      vs 'New York, United States' etc., that would be heavy normalization).
    """
    if not isinstance(place_value, str):
        return np.nan

    s = place_value.strip()

    
    if s.startswith("[") and s.endswith("]"):
        s = s[1:-1].strip()
    if s.startswith("["):
        s = s[1:].strip()
    if s.endswith("]"):
        s = s[:-1].strip()

    if s.lower() in BAD_TOKENS:
        return np.nan

    return s


def extract_years(text):
    """
    Extract all valid 4-digit years from a text string.

    - We only accept years in [1000, 2100] to avoid garbage like '802701'.
    - Returns a list of integers (possibly empty).

    This is used to parse subject_times like:
    "20th century, 1935-1947, 1940, 1941"
    -> [1935, 1940, 1941, 1947]
    """
    if not isinstance(text, str):
        return []

    
    candidates = re.findall(r"\b(\d{4})\b", text)
    years = []
    for y in candidates:
        y_int = int(y)
        if 1000 <= y_int <= 2100:
            years.append(y_int)
    return years



CENTURY_CENTER_YEAR = {
    "17th century": 1650,
    "18th century": 1750,
    "19th century": 1850,
    "20th century": 1950,
    "21st century": 2050,
}


def approximate_year_from_century(text):
    """
    Approximate a single year from century-like or era-like phrases.

    Examples:
    - "19th century"     -> ~1850
    - "20th century"     -> ~1950
    - "21st Century"     -> ~2050
    - "Early 20th century" -> ~1910
    - "Late 20th century"  -> ~1980
    - "Victorian Era"      -> ~1870

    This is a heuristic feature: not historically exact, but good enough
    to capture approximate time for machine learning purposes.
    """
    if not isinstance(text, str):
        return None

    low = text.lower()

    
    if "victorian" in low:
        return 1870  

    if "early 20th" in low:
        return 1910  

    if "late 20th" in low:
        return 1980  

    
    for label, center in CENTURY_CENTER_YEAR.items():
        if label.lower() in low:
            return center

    return None


def compute_subject_time_year(subject_time_value):
    """
    Convert a messy 'subject_times' string into a single numeric feature:
    'subject_time_year'.

    Rules:
    1) If explicit years are present (e.g. "1914-1945, 1940, 1941"):
       - Extract all years and use the median as the representative year.
         (Median is robust and represents the "middle" of the time span.)

    2) If no explicit years, but we find century/era labels:
       - Use an approximate center year (see approximate_year_from_century()).

    3) If neither years nor recognizable centuries/eras exist:
       - Return NaN.

    This gives us ONE numeric feature, which is easier to use in models
    than the raw string column.
    """
    if not isinstance(subject_time_value, str):
        return np.nan

    
    years = extract_years(subject_time_value)
    if years:
        
        years_sorted = sorted(set(years))
        
        return int(np.median(years_sorted))

    
    approx = approximate_year_from_century(subject_time_value)
    if approx is not None:
        return approx


    return np.nan

def normalize_token(t: str) -> str:
    if not isinstance(t, str):
        return ""
    t = t.strip().lower()
    t = re.sub(r"\s+", " ", t)          
    t = t.strip(" .;:!?'\"()[]{}")      
    return t


def make_author_book_counter(author_series):
    """
    Create a function that counts how many books an author has
    in the given dataset.
    """
    counts = author_series.fillna("NA").value_counts()

    def count_author_books(author_name):
        if not isinstance(author_name, str):
            return 0
        return int(counts.get(author_name, 0))

    return count_author_books



def basic_cleaning(df_raw):
    """
    Perform data cleaning and feature engineering on a raw OpenLibrary DataFrame.

    Input:
        df_raw - DataFrame read directly from the scraper output CSV.

    Output:
        df_clean - new DataFrame with:
            - original OpenLibrary columns unchanged,
            - additional cleaned / numeric helper columns.

    The most important new columns are:
        - publisher_clean: cleaned version of publisher
        - publish_place_clean: cleaned version of publish_place
        - subject_places_list: list extracted from subject_places string
        - num_subject_places: number of places in subject_places
        - subject_times_list: list extracted from subject_times string
        - num_subject_times: number of times in subject_times
        - subject_time_year: single numeric year extracted/approximated
        - language_list: list of language codes
        - num_languages: how many languages listed
    """
    
    df = df_raw.copy()

    
    numeric_cols = [
        "first_publish_year",
        "edition_count",
        "number_of_pages_median",
        "ratings_count",
        "ratings_average",
    ]
    for col in numeric_cols:
        
        df[col] = pd.to_numeric(df.get(col, np.nan), errors="coerce")

   
    df["publisher_clean"] = df["publisher"].apply(clean_publisher)

    
    df["publish_place_clean"] = df["publish_place"].apply(clean_publish_place)

    
    df["subject_places_list"] = df["subject_places"].apply(split_list_str)
    df["num_subject_places"] = df["subject_places_list"].apply(len)

    
    df["subject_times_list"] = df["subject_times"].apply(split_list_str)
    df["num_subject_times"] = df["subject_times_list"].apply(len)

    
    df["subject_time_year"] = df["subject_times"].apply(compute_subject_time_year)

   
    df["language_list"] = df["language"].apply(split_list_str)
    df["num_languages"] = df["language_list"].apply(len)

    
    df["subject_list"] = df["subject"].apply(split_list_str)
    df["subject_list"] = df["subject_list"].apply(
        lambda lst: [normalize_token(x) for x in lst if normalize_token(x)]
    )
    df["subject_list"] = df["subject_list"].apply(lambda lst: sorted(set(lst)))

    
    count_author_books = make_author_book_counter(df["author"])
    df["author_book_count"] = df["author"].apply(count_author_books)

    return df



if __name__ == "__main__":
   
    print(f"Loading raw data from: {INPUT_CSV}")
    df_raw = pd.read_csv(INPUT_CSV, encoding="utf-8-sig")
    print(df_raw.columns.tolist())
    
    print("Cleaning data and creating helper features ...")
    df_clean = basic_cleaning(df_raw)
    
    print(f"Saving cleaned data to: {OUTPUT_CSV}")
    df_clean.to_csv(OUTPUT_CSV, index=False, encoding="utf-8-sig")

    print("Done.")